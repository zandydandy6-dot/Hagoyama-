package com.hagoyama;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/** Registers the wielder mob and its spawn egg on its own, so no existing class needed changes. */
@Mod.EventBusSubscriber(modid = HagoyamaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class WielderSetup {
    public static EntityType<HagoyamaWielder> TYPE;
    public static Item EGG;

    private WielderSetup() { }

    @SubscribeEvent
    public static void register(RegisterEvent e) {
        e.register(ForgeRegistries.Keys.ENTITY_TYPES, h -> {
            TYPE = EntityType.Builder.<HagoyamaWielder>of(HagoyamaWielder::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build(HagoyamaMod.MODID + ":hagoyama_wielder");
            h.register(new ResourceLocation(HagoyamaMod.MODID, "hagoyama_wielder"), TYPE);
        });
        e.register(ForgeRegistries.Keys.ITEMS, h -> {
            EGG = new ForgeSpawnEggItem(() -> TYPE, 0x3FB4F2, 0x2A72A8, new Item.Properties());
            h.register(new ResourceLocation(HagoyamaMod.MODID, "hagoyama_wielder_spawn_egg"), EGG);
        });
    }

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(TYPE, HagoyamaWielder.createAttributes().build());
    }

    @SubscribeEvent
    public static void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(EGG);
    }
}
