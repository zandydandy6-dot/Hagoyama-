package com.hagoyama.client;

import com.hagoyama.HagoyamaMod;
import com.hagoyama.HagoyamaWielder;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class WielderRenderer extends HumanoidMobRenderer<HagoyamaWielder, HumanoidModel<HagoyamaWielder>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(HagoyamaMod.MODID, "textures/entity/hagoyama_wielder.png");

    public WielderRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(HagoyamaWielder entity) {
        return TEXTURE;
    }
}
