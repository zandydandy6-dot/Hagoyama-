package com.hagoyama;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Test helpers (op only): /hagoyama trance | awaken | reset */
@Mod.EventBusSubscriber(modid = HagoyamaMod.MODID)
public final class HagoyamaCommands {
    private HagoyamaCommands() { }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("hagoyama").requires(s -> s.hasPermission(2))
                .then(Commands.literal("trance").executes(c -> {
                    Trance.enter(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("awaken").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Trance.data(p).putBoolean(Trance.K_AWAKE, true);
                    c.getSource().sendSuccess(() -> Component.literal("Hagoyama awakened."), false);
                    return 1;
                }))
                .then(Commands.literal("reset").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Trance.data(p).remove(Trance.K_AWAKE);
                    Trance.data(p).remove(Trance.K_CLAIMED);
                    Inventory inv = p.getInventory();
                    for (int i = 0; i < inv.getContainerSize(); i++) {
                        ItemStack s = inv.getItem(i);
                        if (s.getItem() instanceof HagoyamaSwordItem && s.hasTag()) s.getTag().remove(HagoyamaSwordItem.TAG_AWAKE);
                    }
                    c.getSource().sendSuccess(() -> Component.literal("Hagoyama progress reset."), false);
                    return 1;
                })));
    }
}
